
% Mayra Martinez
% ENGI 1331
% 2074058
% mmart227
% Group #8 "Economic effects of solar energy production and consumption"
% NAE project 

clc; clear; close all;
%This set of data allows the user to review prices by year rom 2001 to 2019
list_price = xlsread('Solar-pv-prices.csv'); %loading data
Years = list_price(:,1); % creating a list of years
Prices = list_price(:,2); % creating a list for prices
PricesYear = Prices(26:44); % Taking out the last 20 years
TwentyYears = Years(26:44); % getting values for the last twenty years
TwentyYearsNum = TwentyYears;
TwentyYears = string(TwentyYears); %converting into a string

%TASK 2 
% allow the user to review the prices between 2001 and 2019 by choosing a
% year from the menu
YearSelection = menu('User please select a year from the menu:',TwentyYears);% asking the user to choose a yer
 % If after 5 attempts the user do  not select a year display an error and
 % terminates the program
c=1; %initializing count
while YearSelection == 0
 YearSelection = menu('User please select a year from the menu:',TwentyYears)
  c = c+1;
            if c == 5
                error('User did not make a selection. Program Terminated.')
            end
end

% YearSelection = menu('User please select a year from the menu:',TwentyYears);% asking the user to choose a yer
Price = PricesYear(YearSelection);
ChoosenYear = TwentyYears(YearSelection);
fprintf('\n The price of Solar PV Module Cost in %s was $%.2f [USD/W]\n',ChoosenYear,Price)%outpout fo the choosen year

% adding both years and prices together 
 NewData = [TwentyYears PricesYear];
 
 %TASK 3
 
 % %Call this function 3 times in your main script to outpout the highest
 % and mininimum price with its corresponding year.Also,output the average for t he range of twenty years. 
 
[Max,Min,AVG,HighestPrice,LowestPrice] = PriceperYear(TwentyYears,PricesYear);
%  Max = Max;
%   fprintf('\nThe maximum price of installed Solar PV Module in a range of twenty years was $%0.2f [USD/W]',Max)
fprintf('\nThe highest price of installed Solar PV Module in a range of twenty years was $%0.2f [USD/W] in %s. ',Max,HighestPrice)
fprintf('\nThe lowest price of installed Solar PV Module in a range of twenty years was $%0.2f [USD/W] in %s. ',Min,LowestPrice)
fprintf('\nThe average price of installed Solar PV Module in a range of twenty years was $%0.2f [USD/W]\n',AVG)
 
%Difference in price in a range of 20 years
DChangeinPrice = (Max - Min);
fprintf('\nIn a range of twenty years the price of installed Solar PV Module decreased $%0.2f [USD/W]',DChangeinPrice)

plot(TwentyYearsNum,PricesYear,'or')
title('Prices Vs Time')
xlabel('Years')
ylabel('Prices')
grid on

% Average =[];
% for i= 2:length(PricesYear)-1 % creating a list from 2 to lenght of price
% Average(i-1) = mean(PricesYear(i),PricesYear(i-1),PricesYear(i+1))
% end
% hold on
% plot(TwentyYearsNum(2:end-1),Average,'-b')

